import React from 'react'
import Navbar from './Components/Navbar/AdminNavbar'
import Admin from './Components/Requests/Admin'



const AdminPage = () => {
  return (
   <div>
    <Navbar />
     <h1>DETAILS OF ORPHANAGES AND SPONSORS</h1>
   <div>
     <Admin />
        </div>
    </div>
    
    
    
  )
}

export default AdminPage;
