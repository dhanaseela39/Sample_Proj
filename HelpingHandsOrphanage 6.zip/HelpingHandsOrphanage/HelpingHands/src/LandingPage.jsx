// import React from 'react';
// import Navbar from './Components/Navbar.jsx'
// import './LandingPage.css'; 

// const LandingPage = () => {
//   return (
//     <div>
//       <Navbar />
//       <header className="header">
//         <h1>Helping hands are better than praying lips. - Mother Teresa</h1>
//       </header>
//       <section id="login-section" className="login-section">
//         <h2>Login</h2>
//         <form>
//           <label>Email:</label>
//           <input type="email" placeholder="Enter your email" required />
//           <label>Password:</label>
//           <input type="password" placeholder="Enter your password" required />
//           <label>Login as:</label>
//           <select>
//             <option value="admin">Admin</option>
//             <option value="sponsor">Sponsor</option>
//             <option value="orphanage-home">Orphanage Home</option>
//           </select>
//           <button type="submit">Login</button>
//         </form>
//         <button className="register-button" onClick={() => window.location.href = '/register'}>New User Register</button>
//       </section>
//       <footer id="contact-section" className="contact-section">
//         <h2>Contact Us</h2>
//         <p>Address: No. 420, Abes Nagar, Chennai -31, Tamil Nadu, India</p>
//         <p>Contact number: 123456890</p>
//         <p>Email: helpinghands@gnail.com</p>
//       </footer>
//     </div>
//   );
// }

// export default LandingPage;


//sec2

import React from 'react';
import Navbar from './Components/NavbarLandingPage.jsx';
import './LandingPage.css';

const LandingPage = () => {
  return (
    <div className="landing-page">
      <Navbar />
      <h1 className="quote">
      “Helping hands are better than praying lips.” 
      <h3>- Mother Terasa</h3>
      </h1>
      <header className="header">
      </header>
      <footer id="contact-section" className="contact-section">
        <h2>Contact Us</h2>
        <p>Address: No. 420, Abes Nagar, Chennai -31, Tamil Nadu, India</p>
        <p>Contact number: 123456890</p>
        <p>Email: helpinghands@gnail.com</p>
      </footer>
    </div>
  );
}

export default LandingPage;


// import React from 'react';
// import './LandingPage.css'; // Ensure you have global styles for other elements
// import Navbar from './Components/Navbar'; // Import the Navbar component

// const LandingPage = () => {
//   const backgroundImageStyle = {
//     backgroundImage: 'url(https://drive.google.com/uc?export=view&id=1y77tYT_8QR_jjRoe8E4Ngjy9NiY0K5ks)',
//     backgroundRepeat: 'no-repeat',
//     backgroundSize: 'cover',
//     backgroundPosition: 'center',
//     minHeight: '100vh',
//     color: 'white', 
//     display: 'flex',
//     flexDirection: 'column',
//     justifyContent: 'center',
//     alignItems: 'center',
//     textAlign: 'center'
//   };
//   return (
//     <div style={backgroundImageStyle}>
//       <Navbar />
//       <header className="header">
//         <h1>Helping hands are better than praying lips. - Mother Teresa</h1>
//       </header>
//       <footer id="contact-section" className="contact-section">
//         <h2>Contact Us</h2>
//         <p>Address: No. 420, Abes Nagar, Chennai -31, Tamil Nadu, India</p>
//         <p>Contact number: 123456890</p>
//         <p>Email: helpinghands@gnail.com</p>
//       </footer>
//     </div>
//   );
// }

// export default LandingPage;
