import axios from 'axios';
import { useRef,useState, useEffect} from 'react';
import './LoginPage.css';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const userRef = useRef();
  const errRef = useRef();
  const navigate = useNavigate();
  const [user, setUser] = useState('');
  const [pwd, setPwd] = useState('');
  const [userData,setUserData] = useState({});
  const [errMsg, setErrMsg] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    userRef.current.focus();
  }, []);

  useEffect(() => {
    setErrMsg('');
  }, [user, pwd]);

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the form from reloading the page

    // Perform your login logic here
    try{
      const response=await axios.get(`http://localhost:7777/api/credentials/${user}/${pwd}`);
      if(response.data.id){
        setUserData(response.data);
        setSuccess(true);
        const id=userData.id;
        console.log(response.data.id);
        console.log("login successful");
        success == (true? navigate('/orphanagehome-request', { state: { orphanageId: response.data.id } }) : "Orphanage History");
      }
      else{
        setErrMsg("Invalid credentials")
        console.log(errMsg);
      }
      
    }
    catch(error){
      if (error.response) {
  
        setErrMsg('Invalid username or password');
        console.log(errMsg);
    }
    else{
      setErrMsg('Error: '+error.message);
    }
    }

    // Reset fields and show success
    setUser('');
    setPwd('');
  };

  return (
    <>
      
    
        <section>
        
          <h1>Sign In</h1>
          <form onSubmit={handleSubmit}>
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              ref={userRef}
              autoComplete="off"
              onChange={(e) => setUser(e.target.value)}
              value={user}
              required
            />
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              onChange={(e) => setPwd(e.target.value)}
              value={pwd}
              required
            />
            <button type="submit">Sign In</button>
            <p ref={errRef} className={errMsg ? 'errmsg' : 'offscreen'} aria-live="assertive">
            {errMsg}
          </p>
          
          </form>
          <p>
            Need an Account?<br />
            <span className="line">
              <a href="#">Sign Up</a>
            </span>
          </p>
          
        </section>
      
    </>
  );
};

export default Login;


  


