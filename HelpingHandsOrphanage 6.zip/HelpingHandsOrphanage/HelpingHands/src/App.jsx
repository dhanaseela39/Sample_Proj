// import React from 'react';
// import LandingPage from './LandingPage.jsx';
// import Register from './Register.jsx';
// import RequestHistory from './Components/RequestHistory.jsx';
// import PostRequirement from './PostRequirement.jsx';

// function App(){
//   // return <LandingPage /> 
//     return <Register /> 
//     //  return <RequestHistory /> 
//     // return <PostRequirement />
// }
// export default App;

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LandingPage from './LandingPage';
import LoginAdmin from './LoginAdmin';
import LoginSponsor from './LoginSponsor';
import LoginOrphanageHome from './LoginOrphanageHome';
import Register from './Register';
import RequestHistory from './Components/RequestHistory';
import PostRequirement from './PostRequirement';
import AdminPage from './AdminPage';



const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login-sponsor" element={<LoginSponsor />} />
        <Route path="/login-admin" element={<LoginAdmin />} />
        <Route path="/login-orphanagehome" element={<LoginOrphanageHome />} />
        <Route path="/orphanagehome-request" element={<RequestHistory />} />
        <Route path="/post-new-requirement" element ={<PostRequirement />} />
        <Route path="/admin-page" element ={<AdminPage />} />
      </Routes>
    </Router>
  );
}

export default App;
