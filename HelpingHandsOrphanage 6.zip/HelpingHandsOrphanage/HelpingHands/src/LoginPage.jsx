import React from 'react';
import Navbar from './Components/Navbar.jsx'
import './LoginPage.css';

const LoginPage = () => {
  return (
    <div>
      {/* <Navbar /> */}
      <section id="login-section" className="login-section">
        <h2>Login</h2>
        <form>
          <label>Login as:</label>
          <select>
            <option value="admin">Admin</option>
            <option value="sponsor">Sponsor</option>
            <option value="orphanage-home">Orphanage Home</option>
          </select>
          <label>Email:</label>
          <input type="email" placeholder="Enter your email" required />
          <label>Password:</label>
          <input type="password" placeholder="Enter your password" required />
          <button type="submit">Login</button>
        </form>
        <button className="register-button" onClick={() => window.location.href = '/register'}>New User? Sign Up</button>
      </section>
    </div>
  );
}

export default LoginPage;
