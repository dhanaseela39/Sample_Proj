import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
  }

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  }

  return (
    <nav className="navbar">
      <div className="navbar-logo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
        Helping Hand
      </div>
      <div className="navbar-links">
        <div className="dropdown">
          <button onClick={toggleDropdown}>
            Login
          </button>
          {dropdownOpen && (
            <div className="dropdown-content">
              <Link to="/login-admin">Admin</Link>
              <Link to="/login-sponsor">Sponsor</Link>
              <Link to="/login-orphanagehome">OrphanageHome</Link>
            </div>
          )}
        </div>
        <Link to="/register">
          <button>Register</button>
        </Link>
        <button onClick={() => scrollToSection('contact-section')}>Contact</button>
      </div>
    </nav>
  );
}

export default Navbar;
