import React from 'react'
import './AdminNavbar.css'
import Logo from '/src/assets/logo.svg'


const AdminNavbar = () => {
  return (
    <header className="header">
    <div className="container">
        
        <div className="logo">
            <img src={Logo} alt="Company Logo" />
            <div>
            <h3>Helping Hands</h3>
            </div>
        </div>
        <nav className="nav">
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
        
       
       
        
    </div>
</header>
  )
          
     
}

export default AdminNavbar
