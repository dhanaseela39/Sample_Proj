import React, { useEffect, useState } from 'react';
import NavbarOrphanageHome from './NavbarOrphanageHome';
import './RequestHistory.css';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const RequestHistory = () => {
  const location = useLocation();
  const { orphanageId } = location.state || {};
  const [history,setHistory]=useState([]);
  const navigate=useNavigate();
  //const Id=parseInt(orphanageId);
  useEffect(() => {
    const fetchHistory = async () => {
      if (orphanageId) {
        try {
          const response = await axios.get(`http://localhost:7777/api/requirements/orphanage/history/${orphanageId}`);
          setHistory(response.data);
          console.log(response.data);
        } catch (error) {
          console.error("Error fetching history", error);
        }
      } else {
        console.error("No orphanageId found in state");
      }
    };

    fetchHistory();
  }, [orphanageId]);
  return (
    <div className="request-history">
      <NavbarOrphanageHome />
      <div className="sticky-header">
        <div>
          <h2 className="headline">History of Requirements</h2>
        </div>
        <button className="create-request" onClick={() => navigate('/post-new-requirement', { state: { orphanId: orphanageId } })}>Post New Requirement</button>
      </div>
      <main>
        <div className="requests">
          {history.map((req, index) => (
            <div key={index} className={`request-card ${req.acceptanceStatus}`}>
              <details>
                <summary>Category: {req.category}</summary>
                <p><strong>Description:</strong> {req.description}</p>
                <p><strong>Date:</strong> {req.time}</p>
                <p><strong>Totalquantity/Amound:</strong> {req.totalQuantity}</p>
                <p><strong>Collectedquantity:</strong>{req.collectedQuantity}</p>
                <p className="status"><strong>Status:</strong> {req.acceptanceStatus}</p>
              </details>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default RequestHistory;
