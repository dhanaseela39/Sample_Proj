import React, { useState } from 'react';
import './Pages.css'; // Import the CSS file

// Sample data for illustration
const sampleData = [
  { id: 1, date: '2024-07-31', time: '10:00 AM', orphanageName: 'Sunshine Home', requirementCategory: 'Food', reason: 'Emergency', status: 'pending' },
  { id: 2, date: '2024-07-31', time: '02:00 PM', orphanageName: 'Hope Haven', requirementCategory: 'Clothes', reason: 'Seasonal', status: 'completed' },
  // Add more sample data as needed
];

const Pages = () => {
  const [filter, setFilter] = useState('all');
  const [data, setData] = useState(sampleData);

  const handleButtonClick = (status) => {
    setFilter(status);
  };

  // const handleAcceptReject = (id, action) => {
  //   // Here you would normally make an API call to update the status
  //   const updatedData = data.map(item =>
  //     item.id === id ? { ...item, status: action === 'accept' ? 'completed' : 'rejected' } : item
  //   );
  //   setData(updatedData);
  // };

  const filteredData = data.filter(item => filter === 'all' || item.status === filter);

  return (
    <div className="app-container">
      <div className="button-group">
        <button className={`filter-button ${filter === 'all' ? 'active' : ''}`} onClick={() => handleButtonClick('all')}>All</button>
        <button className={`filter-button ${filter === 'pending' ? 'active' : ''}`} onClick={() => handleButtonClick('pending')}>Pending</button>
        <button className={`filter-button ${filter === 'completed' ? 'active' : ''}`} onClick={() => handleButtonClick('completed')}>Completed</button>
      </div>

      <div className="data-container">
        {filteredData.length > 0 ? (
          filteredData.map(item => (
            <div key={item.id} className="data-item">
              <p><strong>Date:</strong> {item.date}</p>
              <p><strong>Time:</strong> {item.time}</p>
              <p><strong>Orphanage Name:</strong> {item.orphanageName}</p>
              <p><strong>Requirement Category:</strong> {item.requirementCategory}</p>
              <p><strong>Reason:</strong> {item.reason}</p>
              
              {filter === 'pending' && (
                <div className="action-buttons">
                  <button className="action-button accept" onClick={() => handleAcceptReject(item.id, 'accept')}>Accept</button>
                  <button className="action-button reject" onClick={() => handleAcceptReject(item.id, 'reject')}>Reject</button>
                </div>
              )}
            </div>
          ))
        ) : (
          <p>No data available</p>
        )}
      </div>
    </div>
  );
};

export default Pages;
