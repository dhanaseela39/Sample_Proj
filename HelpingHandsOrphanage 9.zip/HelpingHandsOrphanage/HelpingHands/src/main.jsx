import React from 'react'
import ReactDOM from 'react-dom'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
   </React.StrictMode>,
)
// ReactDOM.render(<App />, document.getElementById("root"));
// import React from 'react';
// // import ReactDOM from 'react-dom';
// import './index.css';
// import PostRequirement from './PostRequirement';

// ReactDOM.render(
//   <React.StrictMode>
//     <PostRequirement />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

