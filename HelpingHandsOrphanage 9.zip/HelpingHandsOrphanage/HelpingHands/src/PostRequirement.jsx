import React, { useState } from 'react';
import Navbar from './Components/NavbarOrphanageHome';
import './PostRequirement.css'
import axios from 'axios';
import { useLocation, useNavigate} from 'react-router-dom';

const PostRequirement = () => {
  // const [category, setCategory] = useState('');
  // const [description, setDescription] = useState('');
  // const [totalQuantity, setBeneficiaries] = useState(0);
  const location = useLocation();
  const { orphanId } = location.state || {}; // Access orphanageId from state
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    category: '',
    description: '',
    totalQuantity:0,
  });
  const [idData,setId]=useState({
    id: 0,
  })
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    // Handle form submission, e.g., send data to the server
    console.log("formData: ",formData);
    console.log("id: ",orphanId);
    setId(orphanId);
    console.log("setid: ",idData.id);
    try{
      const response= await axios.post("http://localhost:7777/api/requirements/needs",formData);
      if(response.data){
        console.log(response.data);
        alert('Your Requirement sent to get the approval of Admin. Soon he contacts you');

        setFormData({
          category: '',
          description: '',
          totalQuantity:0,
        });
        const response1= await axios.patch(`http://localhost:7777/api/orphanage/requirement/${response.data.reqId}`,{id: orphanId});
        if(response1.OK){
          console.log("orphanage id is inserted")
        }
        else{
          console.log("orphanage id is not inserted")
        }
        navigate('/');
      }
      else {
        // Show failure message
        alert('Requirement posting was got failed. Please try again.');
      }
    }
    catch (error) {
      console.error('Error submitting form:', error);
      alert('Registration failed. Please try again.');
    }


  };

  // return (
  //   <h1>Hrllo</h1>
  
  return (
    <div className="container">
      <Navbar />
      <h1> We are with you to satisfy your need</h1>
      <form className="requirement-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="category">Category:</label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
          >
            <option value="">Select Category</option>
            <option value="Garbs">Garbs</option>
            <option value="Groceries">Groceries</option>
            <option value="Fund">Fund</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="description">Description:</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            maxLength="5000"
          />
        </div>
        <div className="form-group">
          <label htmlFor="totalQuantity">Count of Beneficiaries:</label>
          <input
            type="number"
            id="totalQuantity"
            name="totalQuantity"
            value={formData.totalQuantity}
            onChange={handleChange}
          />
        </div>
        {/* {category === 'Fund' && (
          <div className="form-group">
            <label htmlFor="reason">Reason:</label>
            <textarea
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </div>
        )} */}
        <button type="submit" className="submit-button">Send to Admin for Approval</button>
      </form>
    </div>
  );
};

export default PostRequirement;
