import React, { useState } from 'react';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import './DonorForm.css'; // Ensure this CSS file is in the same directory or adjust the path as needed
import axios from 'axios'
function DonorForm() {
   // Get the card ID from the URL
  const location = useLocation();
  const { id, amountNeeded, sponsorId } = location.state || {};
  //const amountNeeded = location.state?.amountNeeded; // Access the amountNeeded from the state

  const [formData, setFormData] = useState({
    name: '',
    phoneNumber: null,
    email: '',
    CollectedAmount: 0, // Set initial donation amount to amountNeeded
  });
  const [donationAmount, setDonationAmount]= useState({
    totalQuantity: 0,
    collectedQuantity: 0,
  })

  const navigate = useNavigate(); // Add useNavigate here

  const handleChange = (e) => {
    const { name, value } = e.target;
    let newValue;
    switch(name){
      case 'phoneNumber':
        newValue = parseInt(value, 10);
        break;
      default:
        newValue = value;
        break;
    }
    setFormData((prevData) => ({
      ...prevData,
      [name]: newValue,
    }));
    
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    const totalQuantity = amountNeeded - formData.totalQuantity;
    const collectedQuantity = donationAmount;
    setDonationAmount(
      { totalQuantity, collectedQuantity }
    );
    try{
    const response1= await axios.patch(`http://localhost:7777/api/sponser/requirement/${id}`,{id: sponsorId});
        if(response1.status===200){
          console.log("sponsor id is inserted")
        }
        else{
          console.log("sponsor id is not inserted")
        }
    
    const res = await axios.patch(`http://localhost:7777/admin/quantity/${id}`,donationAmount);
    if(res.data){
      console.log("quantity updated")
    }
    else{
      console.log("quantity not updated")
    }

    
  }
  catch(error)
{
  console.log(error)
}      
setFormData({
      name: '',
      phoneNumber: null,
      email: '',
      CollectedAmount: 0,
    });
    navigate('/thank-you'); // Redirect to ThankYouPage
  };

  return (
    <div className="donor-form-wrapper">
      <div className="donor-container">
        <h1>Fill the form to Donate</h1>
        <form onSubmit={handleSubmit} className="donor-form">
          <div className="form-group">
            <label htmlFor="name">Donor Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="phoneNumber">Contact Number:</label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email Address:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="CollectedAmount">Donation Amount/Quantity:</label>
            <input
              type="number"
              id="CollectedAmount"
              name="CollectedAmount"
              value={formData.CollectedAmount}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="submit-button">Submit</button>
        </form>
      </div>
    </div>
  );
}

export default DonorForm;
