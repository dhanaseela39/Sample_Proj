import React, { useState, useEffect } from 'react';
import './NavbarDonor.css';

const NavbarOrphanageHome = () => {
  const [profileOpen, setProfileOpen] = useState(false);
  const [orphanageDetails, setOrphanageDetails] = useState({});

  useEffect(() => {
    const fetchOrphanageDetails = async () => {
      const details = await Promise.resolve({
        name: "Orphanage Home Name",
        address: "123 Street, City",
        contact: "123-456-7890",
        email: "orphanage@example.com"
      });
      setOrphanageDetails(details);
    };
    fetchOrphanageDetails();
  }, []);

  const toggleProfile = () => {
    setProfileOpen(!profileOpen);
  };

  return (
    <header className="navbar">
      <nav className ="navbarlogo">
      <img src=".\src\assets\logo.svg" alt="Helping hands" className="logo" />
      </nav>

      <nav>
        <a href="/home">Home</a>
        <a href="/contact">Contact</a>
      </nav>
      {/* <div className="profile-icon" onClick={toggleProfile}>
        <img src=".\src\assets\Profile png images _ PNGEgg.png" alt="Profile" />
      </div> */}
      {profileOpen && (
        <div className="profile-modal">
          <div className="profile-content">
            <span className="close" onClick={toggleProfile}>&times;</span>
            <p><strong>Name:</strong> {orphanageDetails.name}</p>
            <p><strong>Address:</strong> {orphanageDetails.address}</p>
            <p><strong>Contact:</strong> {orphanageDetails.contact}</p>
            <p><strong>Email:</strong> {orphanageDetails.email}</p>
          </div>
        </div>
      )}
    </header>
  );
};

export default NavbarOrphanageHome;
