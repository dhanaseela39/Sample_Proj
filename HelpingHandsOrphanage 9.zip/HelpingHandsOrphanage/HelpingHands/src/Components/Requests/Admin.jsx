import axios from 'axios';
import React, { useEffect, useState } from 'react';
import './Admin.css'; // Import the CSS file
import AdminNavbar from '../Navbar/AdminNavbar';

const Pages = () => {
  const [view, setView] = useState(null); // Tracks which section to show
  const [filter, setFilter] = useState('all'); // Tracks the filter for requests
  const [orphanData, setOrphanData] = useState([]); // Data state for orphanages
  const [sponsorData, setSponsorData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);

  const handleButtonClick = (status) => {
    setFilter(status);
  };

  const handleAcceptReject = async (id, action) => {
    const status = action === 'accept' ? 'Accepted' : 'Rejected';
    try {
      const response = await axios.patch(`http://localhost:7777/api/requirements/admin/status/${id}`, { status });
      console.log(response.data);
      if (response.data) {
        console.log("status updated");
        const updatedData = orphanData.map(item =>
          item.reqId === id ? { ...item, status: status } : item
        );
        setOrphanData(updatedData);
      } else {
        console.log("status not updated");
      }
    } catch (error) {
      console.error("status updation error", error);
    }
  };

  useEffect(() => {
    const filteredData = orphanData.filter(item => filter === 'all' || item.status === filter);
    setFilteredData(filteredData);
  }, [orphanData, filter]);

  const handleViewChange = async (viewType) => {
    setView(view === viewType ? null : viewType);
    if (viewType === 'orphanages') {
      try {
        const response1 = await axios.get("http://localhost:7777/api/requirements/admin");
        if (response1.data) {
          setOrphanData(response1.data);
          console.log("orphanData: ", orphanData);
        } else {
          console.log(" error in fetching orphanage data");
        }
      } catch (error) {
        console.log("Error in fetching orphanage details ", error);
      }
    } else {
      try {
        const response1 = await axios.get("http://localhost:7777/api/admin/sponsor/confirmation");
        if (response1.data) {
          setSponsorData(response1.data);
          console.log("SponsorData: ", sponsorData);
        } else {
          console.log(" error in fetching sponsor data");
        }
      } catch (error) {
        console.log("Error in fetching sponsor details ", error);
      }
    }
  };

  const calculateDeadlineClass = (deadline) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const timeDiff = deadlineDate - today;
    const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

    if (dayDiff < 5) {
      return 'deadline-red';
    } else if (dayDiff <= 10) {
      return 'deadline-yellow';
    } else {
      return 'deadline-green';
    }
  };

  return (

    <div className="app-container">
      <AdminNavbar />
      <div className="button-row">
        <button
          className={`main-button ${view === 'orphanages' ? 'active' : ''}`}
          onClick={() => handleViewChange('orphanages')}
        >
          Requests from Orphanages
        </button>

        <button
          className={`main-button ${view === 'sponsors' ? 'active' : ''}`}
          onClick={() => handleViewChange('sponsors')}
        >
          Confirmation from Sponsors
        </button>
      </div>

      {view === 'orphanages' && (
        <div>
          <div className="button-group">
            <button className={`filter-button ${filter === 'all' ? 'active' : ''}`} onClick={() => handleButtonClick('all')}>All</button>
            <button className={`filter-button ${filter === 'pending' ? 'active' : ''}`} onClick={() => handleButtonClick('Pending')}>Pending</button>
            <button className={`filter-button ${filter === 'accepted' ? 'active' : ''}`} onClick={() => handleButtonClick('Accepted')}>Accepted</button>
          </div>

          <div className="data-container">
            {filteredData.length > 0 ? (
              filteredData.map(item => (
                <div key={item.id} className={`data-item ${calculateDeadlineClass(item.deadline)}`}>
                  <p><strong>Name:</strong> {item.name}</p>
                  <p><strong>Description:</strong> {item.description}</p>
                  <p><strong>TotalQuantity:</strong> {item.totalQuantity}</p>
                  <p><strong>Deadline:</strong> {item.deadline}</p>
                  <p><strong>Status:</strong> {item.status}</p>

                  {filter === 'Pending' && (
                    <div className="action-buttons">
                      <button className="action-button accept" onClick={() => handleAcceptReject(item.reqId, 'accept')}>Accept</button>
                      <button className="action-button reject" onClick={() => handleAcceptReject(item.reqId, 'reject')}>Reject</button>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p>No data available</p>
            )}
          </div>
        </div>
      )}

      {view === 'sponsors' && (
        <div className="data-container">
          {sponsorData.length > 0 ? (
            sponsorData.map(item => (
              <div key={item.id} className="data-item">
                <p><strong>Sponsor Name:</strong> {item.name}</p>
                <p><strong>Sponsor Email:</strong> {item.email}</p>
                <p><strong>Phone number:</strong> {item.phone_no}</p>
                <p><strong>Orphanage Name:</strong> {item.orph_name}</p>
                <p><strong>Donating Category:</strong> {item.category}</p>
              </div>
            ))
          ) : (
            <p>No sponsor data available</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Pages;
