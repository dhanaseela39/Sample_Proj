import React from 'react';
import './Card.css'; // Ensure this CSS file is in the same directory or adjust the path as needed

const Card = ({ image, imgAlt, name, description, totalQuantity,deadline, buttonText, onDonateClick }) => {
  return (
    <div className="card-container">
      {image && imgAlt && (
        <img src={image} alt={imgAlt} className="card-img" />
      )}
      {name && <h4 className="card-title">{name}</h4>}
      {description && <p className="card-description">{description}</p>}
      {totalQuantity && <p className="card-amount-needed">AmountNeeded: {totalQuantity}</p>}
      {deadline} <p className="card-postedDate">Donate Dealine: {deadline}</p>
      {buttonText && (
        <button onClick={onDonateClick} className="card-btn">
          {buttonText}
        </button>
      )}
    </div>
  );
};

export default Card;
