import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ThankYouPage.css';

function ThankYouPage() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/donor-view'); // Redirect to DonorView page after 5 seconds
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="thank-you-card">
      <p>Thank you for your donation! 
        An admin will contact you shortly.</p>
    </div>
  );
}

export default ThankYouPage;
