import React from 'react';
import './ButtonsView.css'; // Ensure this CSS file is in the same directory or adjust the path as needed

const ButtonsView = ({ onButtonClick }) => {
  return (
    <div className="buttons-view">
      <button onClick={() => onButtonClick('All')} className="filter-button">All</button>
      <button onClick={() => onButtonClick('fund')} className="filter-button">Fund</button>
      <button onClick={() => onButtonClick('groceries')} className="filter-button">Groceries</button>
      <button onClick={() => onButtonClick('garbs')} className="filter-button">Garbs</button>
    </div>
  );
};

export default ButtonsView;
