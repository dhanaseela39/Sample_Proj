import React, { useState, useEffect } from 'react';
import { useNavigate,useLocation } from 'react-router-dom';
import './DonorView.css';
import Card from './Card';
import ButtonsView from './ButtonsView';
import NavbarOrphanageHome from './NavbarDonor';
//import imagesurl from '../assets/images/orohan3.png';
import axios from 'axios'

const DonorView = () => {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showMessage, setShowMessage] = useState(true);
  const [isBlurred, setIsBlurred] = useState(true);
  const navigate = useNavigate();
  const [filteredCards, setFilterCards] = useState([]);
  const [cards, setCards] = useState([]);
  const location = useLocation();
  const { sponsorId } = location.state || {};
  //   {
  //     id: 1,
  //     // imgSrc: image,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 2000,
  //     postedDate: "2024-08-09",
  //     buttonText: "Donate",
  //     category: "Garbs",

  //   },
  //   {
  //     id: 2,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 5900,
  //     postedDate: "2024-08-07",
  //     buttonText: "Donate",
  //     category: "Fund"

  //   },
  //   {
  //     id: 3,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 6500,
  //     postedDate: "2024-08-09",
  //     buttonText: "Donate",
  //     category: "Fund",

  //   },
  //   {
  //     id: 4,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 50000,
  //     postedDate: "2024-08-09",
  //     buttonText: "Donate",
  //     category: "Groceries"
  //   },
  //   {
  //     id: 5,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 5000,
  //     postedDate: "2024-08-23",
  //     buttonText: "Donate",
  //     category: "Groceries"
  //   },
  //   {
  //     id: 6,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 10000,
  //     postedDate: "2024-08-08",
  //     buttonText: "Donate",
  //     category: "Garbs"
  //   },
  //   {
  //     id: 7,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 25000,
  //     postedDate: "2024-08-23",
  //     buttonText: "Donate",
  //     category: "Garbs"
  //   },
  //   {
  //     id: 8,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 10000,
  //     postedDate: "2024-08-18",
  //     buttonText: "Donate",
  //     category: "Fund"
  //   },
  //   {
  //     id: 9,
  //     imgSrc: imagesurl,
  //     imgAlt: "Card Image 1",
  //     title: "Orphanage-Name1",
  //     description: "We are from the palce. We need help.",
  //     amountNeeded: 20000,
  //     postedDate: "2024-08-11",
  //     buttonText: "Donate",
  //     category: "Groceries"
  //   }
  // ]);
  // const handleButtonClick = (category) => {
  //   setSelectedCategory(category)
  //   if (selectedCategory === 'All')
  //     setFilterCards(cards)
  //   else {
  //     const filtered = cards.filter(card => {
  //       return card.category === category;
  //     });
  //     setFilterCards(filtered);
  //   }
  // };
  const handleButtonClick = (category) => {
    setSelectedCategory(category);
  };


  useEffect(() => {
    if (selectedCategory === 'All') {
        setFilterCards(cards);
    } else {
        const filtered = cards.filter(card => card.category === selectedCategory.toLowerCase());
        console.log('dj',filtered,selectedCategory);
        setFilterCards(filtered);
    }
}, [selectedCategory, cards]);

  const handleDonateClick = (id, amountNeeded) => {
    navigate('/donor-form', {state: {id: id,amountNeeded: amountNeeded,sponsorId: sponsorId}});
  };

  const isEmergency = (postedDate) => {
    const posted = new Date(postedDate);
    const today = new Date();

    posted.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    const timeDifference = posted - today;
    const dayDifference = timeDifference / (1000 * 3600 * 24);

    return dayDifference < 5;
  };

  useEffect(()=>{
    const getCardDetails = async() =>{
    
        try{
      const res = await axios.get("http://localhost:7777/api/requirements/sponsor");
      if(res.data){
        console.log("data",res.data);
      setCards(res.data);
      setFilterCards(res.data);
      }
      else{
        console.log("sponsor fetching error");
      }
        }
        catch(error){
            console.error(error);
        }
    }
    getCardDetails()
  },[])

  useEffect(() => {
    let timer;
    const getEmergencyCards = () => {
      const emergencyCards = cards.filter(card => isEmergency(card.deadline));
      setFilterCards(emergencyCards);
      timer = setTimeout(() => {
        setShowMessage(false);
        setIsBlurred(false);
      }, 2000);
    }
    getEmergencyCards()
    return () => clearTimeout(timer);
  }, [cards]);



  return (
    <div className={`donor-view ${isBlurred ? 'blurred' : ''}`}>
      <NavbarOrphanageHome />
      <ButtonsView onButtonClick={handleButtonClick} />
      {showMessage && (
        <div className="pop-message">
          Donate now to urgent orphanage needs shown below or choose other impactful causes!
        </div>
      )}
      <div className="cardswrapper">
        {filteredCards.length > 0 ? (
          filteredCards.map(card => (
            <Card
              key={card.reqId}
              image={card.image}
              imgAlt="orphanage picture"
              name={card.name}
              description={card.description}
              totalQuantity={card.totalQuantity}
              deadline={card.deadline}
              buttonText="Donate"
              onDonateClick={() => handleDonateClick(card.reqId, card.totalQuantity)}
            />
          ))
        ) : (
          <p>No emergency cards available for the selected category.</p>
        )}
      </div>
    </div>
  );
};

export default DonorView;