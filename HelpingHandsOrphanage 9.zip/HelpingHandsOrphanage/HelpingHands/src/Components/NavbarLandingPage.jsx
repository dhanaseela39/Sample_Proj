import React, { useState } from 'react';
import './NavbarLandingPage.css';

const Navbar = () => {
  const [showDropdown, setShowDropdown] = useState(false);

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav className="navbar">
      <div className="left-section">
        <div className="sitelogo">
          <img src="src\assets\logo.svg" alt="Logo" className="logo-image" />
        </div>
        <div className="site-name" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          Helping Hands
        </div>
      </div>

      <div className="mid-section">
        <a href="/home">Home</a>
        <a href="#contact" onClick={(e) => {e.preventDefault(); scrollToSection('contact-section');}}>Contact</a>
      </div>

      <div className="right-section">
        <button className="login-button" onClick={toggleDropdown}>Login</button>
        {showDropdown && (
          <div className="dropdown-content">
            <a href="/login-admin">Admin</a>
            <a href="/login-sponsor">Sponsor</a>
            <a href="/login-orphanagehome">Orphanage Home</a>
          </div>
        )}
        <button onClick={() => window.location.href = '/register'}>Register</button>
      </div>
    </nav>
  );
};

export default Navbar;
