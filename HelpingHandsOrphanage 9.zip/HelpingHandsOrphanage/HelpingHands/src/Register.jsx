// import React, { useState, useEffect} from 'react';
// // Assuming you have a Navbar component
// import './Register.css';
// import axios from 'axios';

// const Register = () => {
//   const [category, setCategory] = useState('');
  
//   const [adminDetails, setAdminDetails] = useState({
//     name: '',
//     contact: 0,
//     address: '',
//     email: '',
//     password: '',
//     confirmPassword: '',
//   });

//   const [credential, setCredential] = useState({
//     id: null,
//     email:'',
//     password:'',

//   });

//   const [orphanageDetails, setOrphanageDetails] = useState({
//     email: '',
//     name: '',
//     address: '',
//     contactno: null,
//     type: '',
//     govtRegId: null,
//     ownerName: '',
//     ownerAadharNumber: null,
//     gmapLocationUrl: '',
//     imageBase64:'',
//   });

//   const [sponsorDetails, setSponsorDetails] = useState({
//     email: '',
//     name: '',
//     address: '',
//     phone_no: null,
//   });

//   useEffect(() => {
//     const postCredentials = async () => {
//       if (credential.id !== null) {
//         console.log(credential.id);
//         try {
//           const response = await axios.post(`http://localhost:7777/api/credentials/${category}`, credential);
//           console.log(response.data);
//         } catch (error) {
//           console.error("There was an error in posting the credentials", error);
//         }
//       }
//     };

//     postCredentials();

//   }, [credential, category]);

//   const handleChange = (e, setDetails, details) => {
//     const { name, value } = e.target;

//     // Define conversion rules based on field names
//     if(category=== 'OrphanageHome'){
//     let newValue;
//     switch (name) {
//         case 'contact':
//         case 'orphanageGovtId':
//         case 'ownerAadhar':
//             // Convert to number; use null if conversion fails
//             newValue = parseInt(value, 10)
//             break;
//         default:
//             newValue = value;
//             break;
//     }

//     // Update state with the new value
//     setDetails({ ...details, [name]: newValue });
//     }
//     if(category=== 'Sponsor'){
//       let newValue;
//       switch (name) {
//           case 'phone_no':
//               // Convert to number; use null if conversion fails
//               newValue = parseInt(value, 10)
//               break;
//           default:
//               newValue = value;
//               break;
//       }
  
//       // Update state with the new value
//       setDetails({ ...details, [name]: newValue });
//       }
// };

// const handleCredentials =(e, setDetails, details) => {
//   const { name, value} = e.target;
//   console.log(name);
//   setDetails({ ...details, [name]: value });

// };

// const setId=(value, setDetails, details) =>{
//   const name="id";
//   setDetails({ ...details, [name]: value});
// }

// const [user, setUser]=useState({});

//   const handleSubmit = async(e) => {
//     e.preventDefault();
//     if (category === 'Admin') {
//       console.log(adminDetails);
//     } else if (category === 'OrphanageHome') {
//       console.log(orphanageDetails)
//       try{
//       const response=await axios.post("http://localhost:7777/api/orphanage",orphanageDetails);
//       console.log(response.data);
//       setUser(response.data);
//       setId(response.data.orphHomeId, setCredential, credential);
//       }
//       catch(error){
//         console.error("There was an error in fetching",error);
//       }
      
//     } else if (category === 'Sponsor') {
//       console.log(sponsorDetails);
//       try{
//         const response=await axios.post("http://localhost:7777/api/sponser",sponsorDetails);
//         console.log(response.data);
//         setUser(response.data);
//         setId(response.data.sponsorId, setCredential, credential);
//       }
//       catch(error){
//         console.error("There was an error in fetching ",error);
//       }
      
//     }
//   };

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate from react-router-dom
import './Register.css';
import axios from 'axios';

const Register = () => {
  const [category, setCategory] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();  // Initialize useNavigate
  
  // Define user state to store the user data
  const [user, setUser] = useState(null);

  const [adminDetails, setAdminDetails] = useState({
    name: '',
    contact: 0,
    address: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [credential, setCredential] = useState({
    id: null,
    email: '',
    password: '',
  });

  const [orphanageDetails, setOrphanageDetails] = useState({
    email: '',
    name: '',
    address: '',
    contactno: null,
    type: '',
    govtRegId: null,
    ownerName: '',
    ownerAadharNumber: null,
    gmapLocationUrl: '',
    imageBase64: '',
  });

  const [sponsorDetails, setSponsorDetails] = useState({
    email: '',
    name: '',
    address: '',
    phone_no: null,
  });

  useEffect(() => {
    const postCredentials = async () => {
      if (credential.id !== null) {
        try {
          const response = await axios.post(`http://localhost:7777/api/credentials/${category}`, credential);
          console.log(response.data);
        } catch (error) {
          console.error("There was an error in posting the credentials", error);
        }
      }
    };

    postCredentials();

  }, [credential, category]);

  const handleChange = (e, setDetails, details) => {
    const { name, value } = e.target;

    let newValue;
    if (category === 'OrphanageHome') {
      switch (name) {
        case 'contact':
        case 'orphanageGovtId':
        case 'ownerAadhar':
          newValue = parseInt(value, 10);
          break;
        default:
          newValue = value;
          break;
      }
      setDetails({ ...details, [name]: newValue });
    } else if (category === 'Sponsor') {
      switch (name) {
        case 'phone_no':
          newValue = parseInt(value, 10);
          break;
        default:
          newValue = value;
          break;
      }
      setDetails({ ...details, [name]: newValue });
    }
  };

  const handleCredentials = (e, setDetails, details) => {
    const { name, value } = e.target;
    setDetails({ ...details, [name]: value });
  };

  const setId = (value, setDetails, details) => {
    const name = "id";
    setDetails({ ...details, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (category === 'OrphanageHome') {
      try {
        const response = await axios.post("http://localhost:7777/api/orphanage", orphanageDetails);
        setUser(response.data);  // Store user data in state
        setId(response.data.orphHomeId, setCredential, credential);
        setSuccessMessage('You have successfully registered!');
        setTimeout(() => {
          navigate('/login-orphanagehome');  // Use navigate to redirect
        }, 2000);  // Redirect after 2 seconds
      } catch (error) {
        console.error("There was an error in fetching", error);
      }
    } else if (category === 'Sponsor') {
      try {
        const response = await axios.post("http://localhost:7777/api/sponser", sponsorDetails);
        setUser(response.data);  // Store user data in state
        setId(response.data.sponsorId, setCredential, credential);
        setSuccessMessage('You have successfully registered!');
        setTimeout(() => {
          navigate('/login-sponsor');  // Use navigate to redirect
        }, 2000);  // Redirect after 2 seconds
      } catch (error) {
        console.error("There was an error in fetching ", error);
      }
    }
  };

  return (
    <div className="container">
      <h2>Register as</h2>
      <div className="form-group">
        <label htmlFor="category">Category</label>
        <select
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">Select Category</option>
          <option value="OrphanageHome">Orphanage Home</option>
          <option value="Sponsor">Sponsor</option>
        </select>
      </div>
      <form className="register-form" onSubmit={handleSubmit}>
        {category === 'Admin' && (
          <>
            <div className="form-group">
              <label htmlFor="name">Enter your Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={adminDetails.name}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact">Enter Your Contact no:</label>
              <input
                type="text"
                id="contact"
                name="contact"
                value={adminDetails.contact}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails,10)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="address">Enter Your Address:</label>
              <input
                type="text"
                id="address"
                name="address"
                value={adminDetails.address}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Enter your Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={adminDetails.email}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Set Strong Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={adminDetails.password}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm your Password:</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={adminDetails.confirmPassword}
                onChange={(e) => handleChange(e, setAdminDetails, adminDetails)}
              />
            </div>
          </>
        )}
        {category === 'OrphanageHome' && (
          <>
            <div className="form-group">
              <label htmlFor="name">Enter Orphanage Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={orphanageDetails.name}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="contactNo">Enter Orphanage Contact no:</label>
              <input
                type="text"
                id="contactNo"
                name="contactNo"
                value={orphanageDetails.ContactNo}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="address">Enter Orphanage Address:</label>
              <input
                type="text"
                id="address"
                name="address"
                value={orphanageDetails.Address}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Enter orphanage Email id:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={orphanageDetails.Email}
                onChange={(e) => {handleChange(e, setOrphanageDetails, orphanageDetails);handleCredentials(e,setCredential,credential);}}
              />
            </div>
            <div className="form-group">
              <label htmlFor="type">Select the Type of Orphanage:</label>
              <select
                id="type"
                name="type"
                value={orphanageDetails.Type}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              >
                <option value="">Select Type</option>
                <option value="General">General</option>
                <option value="ChildCare">Child Care</option>
                <option value="WomensCare">Women's Care</option>
                <option value="GentsCare">Gents Care</option>
                <option value="ElderCare">Elder Care</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="govtRegId">Enter Govt Register ID of Orphanage:</label>
              <input
                type="text"
                id="govtRegId"
                name="govtRegId"
                value={orphanageDetails.GovtRegId}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="ownerName">Enter Owner Name:</label>
              <input
                type="text"
                id="ownerName"
                name="ownerName"
                value={orphanageDetails.OwnerName}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="ownerAadharNumber">Enter Owner Aadhar Number:</label>
              <input
                type="text"
                id="ownerAadharNumber"
                name="ownerAadharNumber"
                value={orphanageDetails.OwnerAadharNumber}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="gmapLocationUrl">Enter GMap Location URL:</label>
              <input
                type="text"
                id="gmapLocationUrl"
                name="gmapLocationUrl"
                value={orphanageDetails.GmapLocationUrl}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="imageBase64">Enter image URL:</label>
              <input
                type="text"
                id="imageBase64"
                name="imageBase64"
                value={orphanageDetails.imageBase64}
                onChange={(e) => handleChange(e, setOrphanageDetails, orphanageDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Set Strong Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={credential.password}
                onChange={(e) => handleCredentials(e,setCredential,credential)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="">Confirm your Password:</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
            
              />
            </div>
          </>
        )}
        {category === 'Sponsor' && (
          <>
            <div className="form-group">
              <label htmlFor="name">Enter your Name:</label>
              <input
                type="text"
                id="name"
                name="name"
               
                value={sponsorDetails.name}
                onChange={(e) => handleChange(e, setSponsorDetails, sponsorDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone_no">Enter Your Contact no:</label>
              <input
                type="text"
                id="phone_no"
                name="phone_no"
                value={sponsorDetails.phone_no}
                onChange={(e) => handleChange(e, setSponsorDetails, sponsorDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="address">Enter Your Address:</label>
              <input
                type="text"
                id="address"
                name="address"
                value={sponsorDetails.address}
                onChange={(e) => handleChange(e, setSponsorDetails, sponsorDetails)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Enter your Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={sponsorDetails.email}
                onChange={(e) => {handleChange(e, setSponsorDetails, sponsorDetails);handleCredentials(e,setCredential,credential)}}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Set Strong Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={credential.password}
                onChange={(e) => handleCredentials(e, setCredential, credential)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm Your Password:</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
      
              />
            </div>
          </>
        )}
        <button type="submit" className="register-button">Register</button>
      </form>
    </div>
  );
}

export default Register;
