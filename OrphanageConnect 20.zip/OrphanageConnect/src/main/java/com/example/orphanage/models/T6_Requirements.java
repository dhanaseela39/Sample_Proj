package com.example.orphanage.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class T6_Requirements {

    @Id
    @GeneratedValue
    @Column(name="req_id")
    Long reqId;
    @Column(name="category")
    String category;
    @Column(name="description")
    String description;
    @Column(name="acceptance_status")
    String acceptanceStatus;
    @Column(name="total_quantity")
    int totalQuantity;
    @Column(name="collected_quantity")
    int collectedQuantity;
    @Column(name="updated_time")
    Timestamp updatedTime;
    @ManyToOne(cascade= CascadeType.MERGE)
    @JoinColumn(name = "orph_home_id")
    @JsonBackReference(value="reference1")
    T6_Orphanage orphanage;
    @ManyToOne(cascade= CascadeType.MERGE)
    @JoinColumn(name = "sponsor_id")
    @JsonBackReference(value="reference2")
    T6_Sponsor sponsor;
    @ManyToOne(cascade= CascadeType.MERGE)
    @JoinColumn(name = "admin_id")
    @JsonBackReference(value="reference3")
    T6_Admin admin;

    @Override
    public String toString() {
        return "T6_Requirements{id=" + reqId + ", category=" + category + "}";
    }


}
