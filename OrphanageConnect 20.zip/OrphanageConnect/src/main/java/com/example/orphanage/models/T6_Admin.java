package com.example.orphanage.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class T6_Admin {
    @Id
    @GeneratedValue
    @Column(name="admin_id")
    Long AdminId;
    @Column(name="email")
    String Email;
    @Column(name="name")
    String Name;
    @Column(name="address")
    String Address;
    @Column(name="phone_no")
    Long Phone_No;
    @OneToMany(mappedBy = "admin")
    @JsonManagedReference(value="reference3")
    private List<T6_Requirements> requirements;
    @OneToOne(mappedBy = "admin")
    @JsonManagedReference(value="reference4")
    private T6_Credentials credential;
}
