package com.example.orphanage.repositories;


import com.example.orphanage.models.RequirementResponseOnAdmin;
import com.example.orphanage.models.RequirementResponseOnSponsor;
import com.example.orphanage.models.T6_Requirements;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.orphanage.models.OrphanageHistDTO;

import java.util.List;

@Repository
public interface RequirementRepository extends JpaRepository<T6_Requirements, Long> {
//   @Query("SELECT new com.example.orphanage.models.RequirementResponseOnSponsor(r.reqId,o.Name,r.description,r.totalQuantity,r.updatedTime,COALESCE(o.image, '')) "+
//            "FROM T6_Requirements r JOIN r.orphanage o "+
//            "where r.category= :category AND r.acceptanceStatus='Accepted'")
//    List<RequirementResponseOnSponsor> getRequirementsByCategory(@Param("category") String category);

   @Query("SELECT new com.example.orphanage.models.RequirementResponseOnSponsor(r.reqId,o.Name,r.description,r.category,r.totalQuantity,r.updatedTime,COALESCE(o.image, '')) "+
         "FROM T6_Requirements r JOIN r.orphanage o "+
         "where r.acceptanceStatus='Accepted'")
   List<RequirementResponseOnSponsor> getAllRequirementsForSponsor();

   @Query("SELECT new com.example.orphanage.models.RequirementResponseOnAdmin(r.reqId,o.Name,r.description,r.acceptanceStatus,r.totalQuantity,r.updatedTime,COALESCE(o.image, '')) "+
         "FROM T6_Requirements r JOIN r.orphanage o")
   List<RequirementResponseOnAdmin> getAllRequirementsForAdmin();

//    @Query("SELECT new com.example.orphanage.models.RequirementResponseOnSponsor(r.reqId,o.Name,r.description,r.totalQuantity,r.updatedTime,COALESCE(o.image, '')) "+
//            "FROM T6_Requirements r JOIN r.orphanage o "+
//            "where r.acceptanceStatus= :acceptance_status")
//    List<RequirementResponseOnSponsor> getRequirementsByStatus(@Param("acceptance_status") String acceptance_status);

//    @Query("SELECT new com.example.orphanage.models.RequirementResponseOnSponsor(r.reqId,o.Name,r.description,r.totalQuantity,r.updatedTime,COALESCE(o.image, '')) "+
//              "FROM T6_Requirements r JOIN r.orphanage o ")
//    List<RequirementResponseOnSponsor> getRequirements();
    @Query("SELECT new com.example.orphanage.models.OrphanageHistDTO(r.category,r.description,r.acceptanceStatus,r.totalQuantity,r.collectedQuantity,r.updatedTime) "+
         "FROM T6_Requirements r JOIN r.orphanage o WHERE o.OrphHomeId = :orph_home_id")
    List<OrphanageHistDTO> getHistory(@Param("orph_home_id") Long orph_home_id);





}
