package com.example.orphanage.services;
import com.example.orphanage.models.CredentialDTO;
import com.example.orphanage.models.T6_Credentials;

public interface CredentialService {
    CredentialDTO getId(String email, String password);
    T6_Credentials insert(String category, CredentialDTO dto);
}
