package com.example.orphanage.repositories;

import com.example.orphanage.models.T6_Orphanage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrphanRepository extends JpaRepository<T6_Orphanage,Long> {
}
