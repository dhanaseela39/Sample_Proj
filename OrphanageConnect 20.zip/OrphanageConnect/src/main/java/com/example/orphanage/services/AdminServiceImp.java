package com.example.orphanage.services;

import com.example.orphanage.models.SetId;
import com.example.orphanage.models.SponsorConfirmationDTO;
import com.example.orphanage.models.T6_Admin;
import com.example.orphanage.models.T6_Requirements;
import org.springframework.stereotype.Service;
import com.example.orphanage.repositories.AdminRepository;
import com.example.orphanage.repositories.RequirementRepository;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImp implements AdminService{

    AdminRepository adminRepository;

    RequirementRepository requirementRepository;
    public AdminServiceImp(AdminRepository adminRepository,RequirementRepository requirementRepository) {
        this.adminRepository = adminRepository;
        this.requirementRepository=requirementRepository;
    }

    @Override
    public T6_Admin insert(T6_Admin admin){
        return adminRepository.save(admin);
    }

    @Override
    public T6_Admin getAdmin(Long id){
        Optional<T6_Admin> admin = adminRepository.findById(id);
        return admin.orElseThrow(() -> new EntityNotFoundException("Admin not found with id " + id));
        //return adminRepository.getById(id);
    }

    @Override
    public List<SponsorConfirmationDTO> getConfirmations(){
        return adminRepository.getSponsorConfirmations();
    }

    @Override
    public void updateAdminId(Long id, T6_Admin admin){
        T6_Requirements requirement=requirementRepository.findById(id).get();
        requirement.setAdmin(admin);
    }


}
