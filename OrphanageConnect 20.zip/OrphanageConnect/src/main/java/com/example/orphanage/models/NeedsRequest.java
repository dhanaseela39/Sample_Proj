package com.example.orphanage.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Timestamp;

@Data
@Builder
@AllArgsConstructor
public class NeedsRequest {
    @Id
    @GeneratedValue
    Long reqId;
    String category;
    String description;
    String acceptanceStatus;
    int totalQuantity;
    int collectedQuantity;
    Long OrphHomeId;
    Long SponserId;
    Long AdminId;
}
