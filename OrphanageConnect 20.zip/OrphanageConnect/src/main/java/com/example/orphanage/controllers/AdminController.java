package com.example.orphanage.controllers;

import com.example.orphanage.models.T6_Admin;
import com.example.orphanage.models.T6_Orphanage;
import com.example.orphanage.models.T6_Requirements;
import com.example.orphanage.services.AdminService;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.orphanage.models.SponsorConfirmationDTO;
import com.example.orphanage.models.SetId;

import java.util.List;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping
    public ResponseEntity<T6_Admin> saveAdmin(@RequestBody T6_Admin admin){
        T6_Admin admin1=adminService.insert(admin);
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.add("Admin","api/v1/admin"+admin1.getAdminId());
        return new ResponseEntity<>(admin1, HttpStatus.CREATED);
    }
    @GetMapping("/{id}")
    public ResponseEntity<T6_Admin> getAdminDetails(@PathVariable("id") Long id){
        return new ResponseEntity<>(adminService.getAdmin(id),HttpStatus.OK);
    }
    @GetMapping("/sponsor/confirmation")
    public ResponseEntity<List<SponsorConfirmationDTO>> getConfirmations(){
        return new ResponseEntity<>(adminService.getConfirmations(),HttpStatus.OK);
    }

//    @PatchMapping("/{id}")
//    public ResponseEntity<> setAdminId(@PathVariable("id") Long id){
//        adminService.setAdminId(id);
//        return new ResponseEntity(HttpStatus.OK);
//    }
    @PatchMapping(value="/requirement/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> setAdminId(@PathVariable Long id, @RequestBody T6_Admin admin){
        adminService.updateAdminId(id,admin);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
