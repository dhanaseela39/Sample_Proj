package com.example.orphanage.models;

import lombok.Data;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
public class OrphanageDTO {
     @Id
     @GeneratedValue
     Long orphHomeId;
     String email;
     String name;
     String address;
     Long contactNo;
     String type;
     Long govtRegId;
     String ownerName;
     Long ownerAadharNumber;
     String gmapLocationUrl;
     String imageBase64;
}
