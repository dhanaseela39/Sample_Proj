package com.example.orphanage.models;

public enum Status {
    ACCEPTED, REJECTED, PENDING
}
