package com.example.orphanage.models;

import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;
import java.sql.Timestamp;
import java.util.Date;

@Data
@Builder
public class OrphanageHistDTO {
    String category;
    String description;
    String acceptanceStatus;
    int totalQuantity;
    int collectedQuantity;
    Date time;
    public OrphanageHistDTO(String category, String description, String acceptanceStatus, int totalQuantity, int collectedQuantity, Date time) {
        this.category = category;
        this.description = description;
        this.acceptanceStatus = acceptanceStatus;
        this.totalQuantity = totalQuantity;
        this.collectedQuantity = collectedQuantity;
        this.time=time;
    }
}
