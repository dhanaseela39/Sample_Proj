package com.example.orphanage.services;
import com.example.orphanage.models.*;

import com.example.orphanage.repositories.RequirementRepository;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

import com.example.orphanage.repositories.AdminRepository;
import com.example.orphanage.repositories.SponsorRepository;
import com.example.orphanage.repositories.OrphanRepository;

import javax.transaction.Transactional;

@Service
public class RequirementsServiceImp implements RequirementsService{
    RequirementRepository requirementRepository;
    AdminRepository adminRepository;
    SponsorRepository sponsorRepository;
    OrphanRepository orphanageRepository;
    public RequirementsServiceImp(RequirementRepository requirementRepository, AdminRepository adminRepository, SponsorRepository sponsorRepository, OrphanRepository orphanageRepository) {
        this.requirementRepository = requirementRepository;
        this.adminRepository = adminRepository;
        this.sponsorRepository = sponsorRepository;
        this.orphanageRepository = orphanageRepository;
    }

//    @Override
//    public List<RequirementResponseOnSponsor> getNeeds(String category)
//    {
//       try {
//           return requirementRepository.getRequirementsByCategory(category);
//       }
//       catch(Exception e){
//           throw new RuntimeException("Error fetching orphanage needs by category",e);
//       }
//    }
//    @Override
//    public List<RequirementResponseOnSponsor> getNeedByStatus(String category){
//        try {
//            return requirementRepository.getRequirementsByStatus(category);
//        }
//        catch(Exception e){
//            throw new RuntimeException("Error fetching orphanage needs by Status",e);
//        }
//    }

    @Override
    public List<OrphanageHistDTO> getOrphoHistory(Long id) {
        try {
            return requirementRepository.getHistory(id);
        }
        catch(Exception e){
            throw new RuntimeException("Error fetching orphanage history",e);
        }
    }

    @Transactional
    @Override
    public T6_Requirements insert (RequirementDTO dto){

//        if (requirement.getAdminId() == null) {
//            throw new IllegalArgumentException("Admin ID must not be null");
//        }
//        if (requirement.getSponserId() == null) {
//            throw new IllegalArgumentException("Sponser ID must not be null");
//        }
//        if (requirement.getOrphHomeId() == null) {
//            throw new IllegalArgumentException("Orphanage ID must not be null");
     //   }
//        T6_Admin admin = adminRepository.findById(dto.getAdminId())
//                    .orElseThrow(() -> new RuntimeException("Admin not found"));
//        T6_Sponsor sponser = sponsorRepository.findById(dto.getSponserId())
//                .orElseThrow(() -> new RuntimeException("Sponser not found"));
//        T6_Orphanage orphanage = orphanageRepository.findById(dto.getOrphHomeId())
//                .orElseThrow(() -> new RuntimeException("Orphanage not found"));


        // Create the T6_Requirements entity
        T6_Requirements requirements=new T6_Requirements();
        //requirements.setReqId(dto.getReqId());
        requirements.setCategory(dto.getCategory());
        requirements.setDescription(dto.getDescription());
        requirements.setAcceptanceStatus(dto.getAcceptanceStatus());
        requirements.setTotalQuantity(dto.getTotalQuantity());
        requirements.setCollectedQuantity(dto.getCollectedQuantity());
        requirements.setUpdatedTime(new Timestamp(System.currentTimeMillis()));
//        requirements.setAdmin(admin);
//        requirements.setOrphanage(orphanage);
//        requirements.setSponsor(sponser);
        requirements.setAcceptanceStatus(Status.PENDING.name());
        T6_Requirements savedRequirement = requirementRepository.save(requirements);

        // Ensure all lazy-loaded properties are initialized
        Hibernate.initialize(savedRequirement.getAdmin());
        Hibernate.initialize(savedRequirement.getSponsor());
        Hibernate.initialize(savedRequirement.getOrphanage());

        return savedRequirement;
    }
    @Override
    public T6_Requirements updateStatus(Long id, T6_Requirements updateRequirement){

        T6_Requirements requirement=requirementRepository.findById(id).get();
        requirement.setAcceptanceStatus(updateRequirement.getAcceptanceStatus());
        return requirementRepository.save(requirement);

    }
    @Override
    public T6_Requirements updateQuantity(Long id, T6_Requirements updateRequirement){
        T6_Requirements requirement=requirementRepository.findById(id).get();
        requirement.setTotalQuantity(updateRequirement.getTotalQuantity());
        requirement.setCollectedQuantity(updateRequirement.getCollectedQuantity());
        return requirementRepository.save(requirement);

    }
    @Override
    public List<RequirementResponseOnAdmin> getNeedsForAdmin()
    {
        try {
            return requirementRepository.getAllRequirementsForAdmin();
        }
        catch(Exception e){
            throw new RuntimeException("Error fetching orphanage needs by category",e);
        }
    }
    @Override
    public List<RequirementResponseOnSponsor> getNeedsForSponsor()
    {
        try {
            return requirementRepository.getAllRequirementsForSponsor();
        }
        catch(Exception e){
            throw new RuntimeException("Error fetching orphanage needs by category",e);
        }
    }
}
