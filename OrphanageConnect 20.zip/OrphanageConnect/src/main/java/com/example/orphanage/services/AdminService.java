package com.example.orphanage.services;
import com.example.orphanage.models.T6_Admin;
import com.example.orphanage.models.SponsorConfirmationDTO;
import com.example.orphanage.models.SetId;
import java.util.List;

public interface AdminService {
    T6_Admin insert(T6_Admin admin);
    T6_Admin getAdmin(Long id);
    List<SponsorConfirmationDTO> getConfirmations();
    void updateAdminId(Long id,T6_Admin admin);
}
