package com.example.orphanage.controllers;
import com.example.orphanage.models.SetId;
import com.example.orphanage.models.T6_Admin;
import com.example.orphanage.models.T6_Sponsor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.orphanage.services.DonorService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/sponser")
public class DonorController {
    DonorService donorService;
    public DonorController(DonorService donorservice){
        this.donorService=donorservice;
    }

    @PostMapping
    public ResponseEntity<T6_Sponsor> saveDoner(@RequestBody T6_Sponsor doner){
        System.out.println(doner);
        T6_Sponsor donor1=donorService.insert(doner);
        return new ResponseEntity<>(donor1, HttpStatus.CREATED);
    }
    @GetMapping("/{id}")
    public ResponseEntity<T6_Sponsor> getAdminDetails(@PathVariable("id") Long id){
        return new ResponseEntity<>(donorService.getSponsor(id),HttpStatus.OK);
    }

    @PatchMapping(value="/requirement/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> setAdminId(@PathVariable Long id, @RequestBody SetId sponsor){
        donorService.updateSponsorId(id,sponsor);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
