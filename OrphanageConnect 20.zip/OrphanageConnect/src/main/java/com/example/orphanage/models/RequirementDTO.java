package com.example.orphanage.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RequirementDTO {
    String category;
    String description;
    String acceptanceStatus;
    int totalQuantity;
    int collectedQuantity;
    Long OrphHomeId;
    Long SponserId;
    Long AdminId;
}
