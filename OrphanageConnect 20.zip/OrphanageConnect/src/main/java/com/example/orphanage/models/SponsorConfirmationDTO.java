package com.example.orphanage.models;

import lombok.Data;

@Data
public class SponsorConfirmationDTO {
    String name;
    String email;
    Long Phone_no;
    String orph_name;
    String category;

    public SponsorConfirmationDTO(String name, String email, Long phoneNo, String orphanageName, String category) {
        this.name = name;
        this.email = email;
        this.Phone_no = phoneNo;
        this.orph_name = orphanageName;
        this.category = category;
    }
}
