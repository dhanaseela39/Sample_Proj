package com.example.orphanage.controllers;

import com.example.orphanage.models.ErrorResponse;
import com.example.orphanage.models.T6_Credentials;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.orphanage.services.CredentialService;
import com.example.orphanage.models.CredentialDTO;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/credentials")
public class CredentialsContoller{
    CredentialService credentialService;

    public CredentialsContoller(CredentialService credentialService) {
        this.credentialService = credentialService;
    }

    @PostMapping("/{category}")
    public ResponseEntity<T6_Credentials> setCredential(@PathVariable("category") String category, @RequestBody CredentialDTO dto){
        System.out.println(dto);
        return new ResponseEntity<>(credentialService.insert(category,dto),HttpStatus.OK);

    }
//    @GetMapping("/{email}/{password}")
//    public ResponseEntity<CredentialDTO> getCredentialId(@PathVariable("email") String email,@PathVariable("password") String password){
//
//            return new ResponseEntity<>(credentialService.getId(email, password), HttpStatus.OK);
//
//
//    }
@GetMapping("/{email}/{password}")
public ResponseEntity<?> getCredentialId(@PathVariable("email") String email, @PathVariable("password") String password) {
    try {
        CredentialDTO credentialDTO = credentialService.getId(email, password);
        return new ResponseEntity<>(credentialDTO, HttpStatus.OK);
    } catch (RuntimeException ex) {
        // You can return a more specific error message if needed
        return new ResponseEntity<>(new ErrorResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
    } catch (Exception ex) {
        return new ResponseEntity<>(new ErrorResponse("Internal Server Error: " + ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
}
