package com.example.orphanage.controllers;

import com.example.orphanage.models.*;
import com.example.orphanage.services.RequirementsService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/requirements")
public class RequirementsController{

    RequirementsService requirementsService;

    public RequirementsController(RequirementsService requirementsService) {
        this.requirementsService = requirementsService;
    }
//    @GetMapping({"donor/category/{category}"})
//    public ResponseEntity<?>  getNeedByCategory(@PathVariable("category") String category ){
//        try {
//            List<RequirementResponseOnSponsor> needs = requirementsService.getNeeds(category);
//            return new ResponseEntity<>(needs, HttpStatus.OK);
//        }
//        catch (Exception e){
//            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
    @GetMapping("/sponser")
    public ResponseEntity<?>  getNeedForSponser(){
        try {
            List<RequirementResponseOnSponsor> needs = requirementsService.getNeedsForSponsor();
            return new ResponseEntity<>(needs, HttpStatus.OK);
        }
        catch (Exception e){
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/admin")
    public ResponseEntity<?>  getNeedForAdmin(){
        try {
            List<RequirementResponseOnAdmin> needs = requirementsService.getNeedsForAdmin();
            return new ResponseEntity<>(needs, HttpStatus.OK);
        }
        catch (Exception e){
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @GetMapping({"admin/status/{acceptancestatus}"})
//    public ResponseEntity<?>  getNeedsByStatus(@PathVariable("acceptancestatus") String status ){
//        try {
//            List<RequirementResponseOnSponsor> needs = requirementsService.getNeedByStatus(status);
//            return new ResponseEntity<>(needs, HttpStatus.OK);
//        }
//        catch (Exception e){
//            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
    @GetMapping("/orphanage/history/{id}")
    public ResponseEntity<?>  getHistory(@PathVariable("id") Long id ){
        try {
            System.out.println("id: "+id);
            List<OrphanageHistDTO> needs = requirementsService.getOrphoHistory(id);
            return new ResponseEntity<>(needs, HttpStatus.OK);
        }
        catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/needs")
    public ResponseEntity<T6_Requirements> saveRequirements(@RequestBody RequirementDTO requirements){
        System.out.println("endpoint");
        System.out.println(requirements);
        T6_Requirements requirements1 = requirementsService.insert(requirements);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("requirements", "api/requirements/needs" + requirements1.getReqId().toString());
        return new ResponseEntity<>(requirements1, httpHeaders, HttpStatus.CREATED);
    }
    @PatchMapping(value="/admin/status/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<T6_Requirements> updateRequirement(@PathVariable Long id,@RequestBody T6_Requirements requirements){
        T6_Requirements requirements1=requirementsService.updateStatus(id,requirements);
        return new ResponseEntity<>(requirements1,HttpStatus.OK);
    }
    @PatchMapping(value="/admin/quantity/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<T6_Requirements> updateRequirementQuantity(@PathVariable Long id,@RequestBody T6_Requirements requirements){
        T6_Requirements requirements1=requirementsService.updateQuantity(id,requirements);
        return new ResponseEntity<>(requirements1,HttpStatus.OK);
    }

}
