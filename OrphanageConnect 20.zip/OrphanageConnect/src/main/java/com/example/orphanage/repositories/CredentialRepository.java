package com.example.orphanage.repositories;

import com.example.orphanage.models.T6_Credentials;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CredentialRepository extends JpaRepository<T6_Credentials,Long> {
    @Query("SELECT c From T6_Credentials c "+
            "WHERE email= :email AND password= :password")
    T6_Credentials getCredentials(@Param("email") String email, @Param("password") String Password);
}
