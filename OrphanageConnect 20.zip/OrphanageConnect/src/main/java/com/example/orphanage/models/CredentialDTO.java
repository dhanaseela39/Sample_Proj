package com.example.orphanage.models;

import lombok.Builder;
import lombok.Data;

@Data
public class CredentialDTO {
    Long id;
    String email;
    String password;
}
