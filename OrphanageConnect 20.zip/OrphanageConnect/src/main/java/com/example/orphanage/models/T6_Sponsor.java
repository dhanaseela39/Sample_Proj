package com.example.orphanage.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class T6_Sponsor {
    @Id
    @GeneratedValue
    @Column(name="sponsor_id")
    Long SponsorId;
    @JsonProperty("email")
    @Column(name="email")
    String Email;
    @JsonProperty("name")
    @Column(name="name")
    String Name;
    @JsonProperty("address")
    @Column(name="address")
    String Address;
    @JsonProperty("phone_no")
    @Column(name="phone_no")
    Long Phone_no;
    @OneToMany(mappedBy = "sponsor")
    @JsonManagedReference(value="reference2")
    private List<T6_Requirements> requirements;
    @OneToOne(mappedBy = "sponsor")
    @JsonManagedReference(value="reference5")
    private T6_Credentials credential;
}
