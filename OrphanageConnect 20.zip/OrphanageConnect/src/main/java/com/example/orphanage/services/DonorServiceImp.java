package com.example.orphanage.services;
import com.example.orphanage.models.*;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import com.example.orphanage.repositories.SponsorRepository;
import com.example.orphanage.repositories.RequirementRepository;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import java.util.Optional;

@Service
public class DonorServiceImp implements DonorService {

    SponsorRepository sponsorRepository;
    RequirementRepository requirementRepository;

    public DonorServiceImp(SponsorRepository sponsorRepository,RequirementRepository requirementRepository){
        this.sponsorRepository =sponsorRepository;
        this.requirementRepository=requirementRepository;
    }

    @Override
    public T6_Sponsor insert(T6_Sponsor sponser){
        return sponsorRepository.save(sponser);
    }

    @Override
    public T6_Sponsor getSponsor(Long id){
        Optional<T6_Sponsor> sponsor = sponsorRepository.findById(id);
        return sponsor.orElseThrow(() -> new EntityNotFoundException("sponsor not found with id " + id));
        //return adminRepository.getById(id);
    }

    @Override
    @Transactional
    public void updateSponsorId(Long id, SetId sponsor) {
        //System.out.println(sponsor);
        //System.out.println("id "+id);
        Optional<T6_Requirements> requirementOptional = requirementRepository.findById(id);
        if (requirementOptional.isEmpty()) {
            throw new RuntimeException("Requirement not found for ID: ");
        }
        T6_Requirements requirement = requirementOptional.get();
        //System.out.println("Fetched Requirement: " + requirement);

        //T6_Requirements requirement = requirementRepository.findById(id).get();
        System.out.println(requirement);
        T6_Sponsor sponsor1 = sponsorRepository.findById(sponsor.getId())
                .orElseThrow(() -> new RuntimeException("Sponsor not found"));
        //System.out.println("sponsor "+sponsor1);
        requirement.setSponsor(sponsor1);
        requirementRepository.save(requirement);
        Hibernate.initialize(requirement.getSponsor());
        //System.out.println("requirement "+requirementRepository.findById(id));
        T6_Requirements updatedRequirement = requirementRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Requirement not found"));
        //System.out.println("Updated Requirement with Sponsor: " + updatedRequirement.getSponsor());
    }
}
