package com.example.orphanage.services;
import com.example.orphanage.models.*;
import com.example.orphanage.repositories.OrphanRepository;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import com.example.orphanage.repositories.RequirementRepository;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
public class OrphanServiceImp implements OrphanService{

    OrphanRepository orphanRepository;
    RequirementRepository requirementRepository;

    public OrphanServiceImp(OrphanRepository orphanRepository,RequirementRepository requirementRepository) {

        this.orphanRepository = orphanRepository;
        this.requirementRepository=requirementRepository;
    }

    @Override
    public T6_Orphanage insert(OrphanageDTO orphanageDTO){

        T6_Orphanage orphanage = T6_Orphanage.builder()
                .OrphHomeId(orphanageDTO.getOrphHomeId())
                .Email(orphanageDTO.getEmail())
                .Name(orphanageDTO.getName())
                .Address(orphanageDTO.getAddress())
                .ContactNo(orphanageDTO.getContactNo())
                .Type(orphanageDTO.getType())
                .GovtRegId(orphanageDTO.getGovtRegId())
                .OwnerName(orphanageDTO.getOwnerName())
                .OwnerAadharNumber(orphanageDTO.getOwnerAadharNumber())
                .GmapLocationUrl(orphanageDTO.getGmapLocationUrl())
                //.image(Base64.getDecoder().decode(orphanageDTO.getImageBase64()))
                .image(orphanageDTO.getImageBase64())
                .build();

        return orphanRepository.save(orphanage);
    }
    @Override
    public T6_Orphanage getOrphanage(Long id){
        Optional<T6_Orphanage> orphan = orphanRepository.findById(id);
        return orphan.orElseThrow(() -> new EntityNotFoundException("Admin not found with id " + id));
        //return adminRepository.getById(id);
    }

    @Override
    public void updateOrphanId(Long id, SetId orphanage){
        System.out.println(orphanage);
        T6_Requirements requirement=requirementRepository.findById(id).get();
        T6_Orphanage orphanage1 = orphanRepository.findById(orphanage.getId())
               .orElseThrow(() -> new RuntimeException("Orphanage not found"));
        requirement.setOrphanage(orphanage1);
        requirementRepository.save(requirement);
        Hibernate.initialize(requirement.getOrphanage());
    }
}
