package com.example.orphanage.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class T6_Orphanage {
    @Id
    @GeneratedValue
    @Column(name="orph_home_id")
    Long OrphHomeId;
    @Column(name="email")
    String Email;
    @Column(name="name")
    String Name;
    @Column(name="address")
    String Address;
    @Column(name="contact_no")
    Long ContactNo;
    @Column(name="type")
    String Type;
    @Column(name="govt_reg_id")
    Long GovtRegId;
    @Column(name="owner_name")
    String OwnerName;
    @Column(name="owner_aadhar_number")
    Long OwnerAadharNumber;
    @Column(name="gmap_location_url")
    String GmapLocationUrl;
    @Lob
    @Column(name="image")
    String image;
    //byte[] image;
    @OneToMany(mappedBy = "orphanage",fetch = FetchType.LAZY)
    @JsonManagedReference(value="reference1")
    private List<T6_Requirements> requirements;
    @OneToOne(mappedBy = "orphanage")
    @JsonManagedReference(value="reference6")
    private T6_Credentials credential;

    @Override
    public String toString() {
        return "T6_Orphanage{id=" + OrphHomeId + ", name=" + Name + "}";
    }
}

