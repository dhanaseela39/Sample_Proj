package com.example.orphanage.repositories;

import com.example.orphanage.models.SponsorConfirmationDTO;
import com.example.orphanage.models.T6_Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminRepository extends JpaRepository<T6_Admin, Long> {

    @Query("SELECT new com.example.orphanage.models.SponsorConfirmationDTO(s.Name,s.Email,s.Phone_no,o.Name,r.category) "+
            "FROM T6_Sponsor s JOIN s.requirements r JOIN r.orphanage o")
    List<SponsorConfirmationDTO> getSponsorConfirmations();
}
