package com.example.orphanage.services;

import java.util.List;

import com.example.orphanage.models.*;

public interface RequirementsService {

//    List<RequirementResponseOnSponsor> getNeeds(String category);
//    List<RequirementResponseOnSponsor> getNeedByStatus(String status);
    List<RequirementResponseOnSponsor> getNeedsForSponsor();
    List<RequirementResponseOnAdmin> getNeedsForAdmin();
    List<OrphanageHistDTO> getOrphoHistory(Long id);
    T6_Requirements insert(RequirementDTO dto);
    T6_Requirements updateStatus(Long id,T6_Requirements updaterequirement);
    T6_Requirements updateQuantity(Long id,T6_Requirements updaterequirement);


}

