package com.example.orphanage.services;
import com.example.orphanage.models.CredentialDTO;
import com.example.orphanage.models.SetId;
import com.example.orphanage.models.T6_Sponsor;
public interface DonorService {
    T6_Sponsor insert(T6_Sponsor sponser);
    T6_Sponsor getSponsor(Long id);
    void updateSponsorId(Long id, SetId sponsor);
}
