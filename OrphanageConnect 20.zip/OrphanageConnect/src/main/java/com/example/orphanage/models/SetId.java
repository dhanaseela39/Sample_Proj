package com.example.orphanage.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SetId {
    Long id;

    public SetId(Long id) {
        this.id = id;
    }
}
