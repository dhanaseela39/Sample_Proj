package com.example.orphanage.services;

import com.example.orphanage.models.*;
import com.example.orphanage.repositories.CredentialRepository;
import com.example.orphanage.repositories.SponsorRepository;
import org.apache.commons.lang3.ObjectUtils;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import com.example.orphanage.repositories.OrphanRepository;

@Service
public class CredentialServiceImp implements CredentialService{
    CredentialRepository credentialRepository;
    OrphanRepository orphanRepository;
    SponsorRepository sponsorRepository;

    public CredentialServiceImp(CredentialRepository credentialRepository, OrphanRepository orphanRepository, SponsorRepository sponsorRepository) {
        this.credentialRepository = credentialRepository;
        this.orphanRepository=orphanRepository;
        this.sponsorRepository=sponsorRepository;
    }

    @Override
    public CredentialDTO getId(String email, String password) {
        T6_Credentials credential = credentialRepository.getCredentials(email, password);
        if(credential==null){
            throw new RuntimeException("Invalid credentials");
        }
        CredentialDTO credentialDTO=new CredentialDTO();
        if (credential.getAdmin() != null && credential.getAdmin().getAdminId() != null) {
            credentialDTO.setId(credential.getAdmin().getAdminId());
        }
        if (credential.getOrphanage() != null && credential.getOrphanage().getOrphHomeId() != null) {
            credentialDTO.setId(credential.getOrphanage().getOrphHomeId());
        }
        if (credential.getSponsor() != null && credential.getSponsor().getSponsorId() != null) {
            credentialDTO.setId(credential.getSponsor().getSponsorId());
        }
        credentialDTO.setEmail(email);
        credentialDTO.setPassword(password);
        return credentialDTO;

    }
    @Override
    public T6_Credentials insert(String category, CredentialDTO dto) {
        T6_Credentials credential = new T6_Credentials();
        credential.setEmail(dto.getEmail());
        credential.setPassword(dto.getPassword());
        if ("OrphanageHome".equals(category)) {
            T6_Orphanage orphan = orphanRepository.findById(dto.getId()).get();
            System.out.println(orphan);
            credential.setOrphanage(orphan);
            Hibernate.initialize(credential.getOrphanage());


        }
        if ("Sponsor".equals(category)) {
            T6_Sponsor sponsor = sponsorRepository.findById(dto.getId()).get();
            credential.setSponsor(sponsor);
            Hibernate.initialize(credential.getSponsor());
        }
        return credentialRepository.save(credential);
    }
}
