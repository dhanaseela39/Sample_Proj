package com.example.orphanage.services;

import com.example.orphanage.models.OrphanageDTO;
import com.example.orphanage.models.SetId;
import com.example.orphanage.models.T6_Orphanage;

public interface OrphanService {
    T6_Orphanage insert(OrphanageDTO orphanageDTO);
    T6_Orphanage getOrphanage(Long id);
    void updateOrphanId(Long id, SetId orphanage);
}
