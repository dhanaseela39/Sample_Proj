package com.example.orphanage.controllers;

import com.example.orphanage.models.OrphanageDTO;
import com.example.orphanage.models.SetId;
import com.example.orphanage.models.T6_Sponsor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.orphanage.models.T6_Orphanage;
import com.example.orphanage.services.OrphanService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/orphanage")
public class OrphanController {

    OrphanService orphanService;

    public OrphanController(OrphanService orphanService) {
        this.orphanService = orphanService;
    }

    @PostMapping
    public ResponseEntity<T6_Orphanage> saveOrphan(@RequestBody OrphanageDTO orphanageDTO){
        System.out.println(orphanageDTO);
        T6_Orphanage orphanage1=orphanService.insert(orphanageDTO);
        return new ResponseEntity<>(orphanage1, HttpStatus.CREATED);
    }
    @GetMapping("/{id}")
    public ResponseEntity<T6_Orphanage> getAdminDetails(@PathVariable("id") Long id){
        return new ResponseEntity<>(orphanService.getOrphanage(id),HttpStatus.OK);
    }

    @PatchMapping(value="/requirement/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> setOrphanageId(@PathVariable Long id, @RequestBody SetId orphanage){
        orphanService.updateOrphanId(id,orphanage);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
