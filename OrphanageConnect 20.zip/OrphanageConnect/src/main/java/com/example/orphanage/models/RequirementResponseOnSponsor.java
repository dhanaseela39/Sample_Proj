package com.example.orphanage.models;


import lombok.Data;

import java.sql.Timestamp;
import java.time.DateTimeException;
import java.util.Date;

@Data
public class RequirementResponseOnSponsor {
    Long reqId;
    String name;
    String description;
    String category;
    int totalQuantity;
    Date updatedTime;
    String image;

    public RequirementResponseOnSponsor(Long reqId, String name, String description,String category, int totalQuantity, Date updatedTime, String image) {
        this.reqId=reqId;
        this.name = name;
        this.description = description;
        this.category=category;
        this.totalQuantity = totalQuantity;
        this.updatedTime=updatedTime;
        this.image =image;
    }
//    public RequirementResponseOnSponsor(Long reqId, String name, String description, int totalQuantity, Date updatedTime, String image) {
//        this.reqId = reqId;
//        this.name = name;
//        this.description = description;
//        this.totalQuantity = totalQuantity;
//        //this.updatedTime = new Timestamp(updatedTime.getTime());
//        this.updatedTime = updatedTime;
//        this.image = image;
//    }

}
