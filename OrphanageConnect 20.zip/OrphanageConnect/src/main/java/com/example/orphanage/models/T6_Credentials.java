package com.example.orphanage.models;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class T6_Credentials {

    @Id
    @GeneratedValue
    @Column(name="credential_id")
    Long Credential_Id;
    @Column(name="email")
    String email;
    @Column(name="password")
    String password;
    @OneToOne
    @JoinColumn(name="admin_id")
    @JsonBackReference(value="reference4")
    T6_Admin admin;
    @OneToOne
    @JoinColumn(name="sponsor_id")
    @JsonBackReference(value="reference5")
    T6_Sponsor sponsor;
    @OneToOne
    @JoinColumn(name="orph_home_Id")
    @JsonBackReference(value="reference6")
    T6_Orphanage orphanage;
}
