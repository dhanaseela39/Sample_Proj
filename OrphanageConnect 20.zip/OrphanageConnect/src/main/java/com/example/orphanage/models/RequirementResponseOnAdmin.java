package com.example.orphanage.models;

import lombok.Data;

import java.util.Date;

@Data
public class RequirementResponseOnAdmin {
    Long reqId;
    String name;
    String description;
    String Status;
    int totalQuantity;
    Date updatedTime;
    String image;

    public RequirementResponseOnAdmin(Long reqId, String name, String description,String Status, int totalQuantity, Date updatedTime, String image) {
        this.reqId=reqId;
        this.name = name;
        this.description = description;
        this.Status=Status;
        this.totalQuantity = totalQuantity;
        this.updatedTime=updatedTime;
        this.image =image;
    }
}
